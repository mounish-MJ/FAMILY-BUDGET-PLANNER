
  # My Family Budget

  This is a code bundle for My Family Budget. The original project is available at https://www.figma.com/design/XWpEaV0hg0ylpD1CXYXNXu/My-Family-Budget.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  