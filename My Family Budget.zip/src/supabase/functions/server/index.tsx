import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2.47.10';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Enable CORS and logging
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization']
}));
app.use('*', logger(console.log));

// Create Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') || '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
);

// Routes for family budget management
app.get('/make-server-d0995623/families/:familyId', async (c) => {
  try {
    const familyId = c.req.param('familyId');
    
    // Get family data
    const familyData = await kv.get(`family:${familyId}`);
    const members = await kv.getByPrefix(`family:${familyId}:members:`);
    const categories = await kv.getByPrefix(`family:${familyId}:categories:`);
    
    return c.json({
      success: true,
      family: familyData,
      members: members,
      categories: categories
    });
  } catch (error) {
    console.log('Error getting family data:', error);
    return c.json({ success: false, error: 'Failed to get family data' }, 500);
  }
});

app.post('/make-server-d0995623/families', async (c) => {
  try {
    const { familyName, familyId } = await c.req.json();
    
    const familyData = {
      id: familyId,
      name: familyName,
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`family:${familyId}`, familyData);
    
    return c.json({ success: true, family: familyData });
  } catch (error) {
    console.log('Error creating family:', error);
    return c.json({ success: false, error: 'Failed to create family' }, 500);
  }
});

app.post('/make-server-d0995623/families/:familyId/members', async (c) => {
  try {
    const familyId = c.req.param('familyId');
    const memberData = await c.req.json();
    
    const member = {
      ...memberData,
      createdAt: new Date().toISOString()
    };
    
    await kv.set(`family:${familyId}:members:${member.id}`, member);
    
    return c.json({ success: true, member });
  } catch (error) {
    console.log('Error adding family member:', error);
    return c.json({ success: false, error: 'Failed to add family member' }, 500);
  }
});

app.delete('/make-server-d0995623/families/:familyId/members/:memberId', async (c) => {
  try {
    const familyId = c.req.param('familyId');
    const memberId = c.req.param('memberId');
    
    await kv.del(`family:${familyId}:members:${memberId}`);
    
    return c.json({ success: true });
  } catch (error) {
    console.log('Error removing family member:', error);
    return c.json({ success: false, error: 'Failed to remove family member' }, 500);
  }
});

app.post('/make-server-d0995623/families/:familyId/categories', async (c) => {
  try {
    const familyId = c.req.param('familyId');
    const categoryData = await c.req.json();
    
    const category = {
      ...categoryData,
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`family:${familyId}:categories:${category.id}`, category);
    
    return c.json({ success: true, category });
  } catch (error) {
    console.log('Error updating budget category:', error);
    return c.json({ success: false, error: 'Failed to update budget category' }, 500);
  }
});

app.put('/make-server-d0995623/families/:familyId/categories/:categoryId', async (c) => {
  try {
    const familyId = c.req.param('familyId');
    const categoryId = c.req.param('categoryId');
    const updates = await c.req.json();
    
    const existingCategory = await kv.get(`family:${familyId}:categories:${categoryId}`);
    if (!existingCategory) {
      return c.json({ success: false, error: 'Category not found' }, 404);
    }
    
    const updatedCategory = {
      ...existingCategory,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    
    await kv.set(`family:${familyId}:categories:${categoryId}`, updatedCategory);
    
    return c.json({ success: true, category: updatedCategory });
  } catch (error) {
    console.log('Error updating budget category:', error);
    return c.json({ success: false, error: 'Failed to update budget category' }, 500);
  }
});

app.get('/make-server-d0995623/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

Deno.serve(app.fetch);