import FamilyBudgetAppWithPersistence from "./components/FamilyBudgetAppWithPersistence";
import { Toaster } from "./components/ui/sonner";

export default function App() {
  return (
    <>
      <FamilyBudgetAppWithPersistence />
      <Toaster />
    </>
  );
}