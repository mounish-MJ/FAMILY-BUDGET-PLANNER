import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Plus, Trash2, DollarSign, Users, Target, TrendingUp, Save, Loader2, Calculator } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { toast } from "sonner@2.0.3";
import BudgetPlanningPage from "./BudgetPlanningPage";

interface FamilyMember {
  id: string;
  name: string;
  role: string;
  monthlyIncome: number;
}

interface BudgetCategory {
  id: string;
  name: string;
  budgetAmount: number;
  actualSpent: number;
  color: string;
}

export default function FamilyBudgetAppWithPersistence() {
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [budgetCategories, setBudgetCategories] = useState<BudgetCategory[]>([
    { id: "1", name: "Groceries", budgetAmount: 0, actualSpent: 0, color: "#8884d8" },
    { id: "2", name: "Utilities", budgetAmount: 0, actualSpent: 0, color: "#82ca9d" },
    { id: "3", name: "Transportation", budgetAmount: 0, actualSpent: 0, color: "#ffc658" },
    { id: "4", name: "Entertainment", budgetAmount: 0, actualSpent: 0, color: "#ff7300" },
    { id: "5", name: "Healthcare", budgetAmount: 0, actualSpent: 0, color: "#00c49f" },
    { id: "6", name: "Education", budgetAmount: 0, actualSpent: 0, color: "#ffbb28" },
  ]);

  const [newMember, setNewMember] = useState({ name: "", role: "", monthlyIncome: "" });
  const [newCategory, setNewCategory] = useState({ name: "", budgetAmount: "" });
  const [familyId, setFamilyId] = useState(() => {
    // Generate or get existing family ID
    const stored = localStorage.getItem('familyBudgetId');
    return stored || `family_${Date.now()}`;
  });
  const [familyName, setFamilyName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);
  const [showBudgetPlanning, setShowBudgetPlanning] = useState(false);

  // Save family ID to localStorage
  useEffect(() => {
    localStorage.setItem('familyBudgetId', familyId);
  }, [familyId]);

  // Load data on component mount
  useEffect(() => {
    loadFamilyData();
  }, []);

  const apiCall = async (endpoint: string, options: RequestInit = {}) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-d0995623${endpoint}`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
          ...options.headers,
        },
        ...options,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error(`API call failed for ${endpoint}:`, error);
      throw error;
    }
  };

  const loadFamilyData = async () => {
    try {
      setIsLoading(true);
      const response = await apiCall(`/families/${familyId}`);
      
      if (response.success) {
        if (response.family) {
          setFamilyName(response.family.name || '');
        }
        
        if (response.members && response.members.length > 0) {
          setFamilyMembers(response.members);
        }
        
        if (response.categories && response.categories.length > 0) {
          setBudgetCategories(response.categories);
        }
      }
      setIsInitialized(true);
    } catch (error) {
      console.error('Error loading family data:', error);
      setIsInitialized(true);
      toast.error('Failed to load family data');
    } finally {
      setIsLoading(false);
    }
  };

  const saveFamilyData = async () => {
    try {
      setIsLoading(true);
      
      // Create/update family
      if (!isInitialized) {
        await apiCall('/families', {
          method: 'POST',
          body: JSON.stringify({
            familyId,
            familyName: familyName || 'My Family Budget'
          }),
        });
      }

      // Save all members
      for (const member of familyMembers) {
        await apiCall(`/families/${familyId}/members`, {
          method: 'POST',
          body: JSON.stringify(member),
        });
      }

      // Save all categories
      for (const category of budgetCategories) {
        await apiCall(`/families/${familyId}/categories`, {
          method: 'POST',
          body: JSON.stringify(category),
        });
      }

      toast.success('Family budget data saved successfully!');
    } catch (error) {
      console.error('Error saving family data:', error);
      toast.error('Failed to save family data');
    } finally {
      setIsLoading(false);
    }
  };

  const addFamilyMember = async () => {
    if (newMember.name && newMember.role && newMember.monthlyIncome) {
      const member: FamilyMember = {
        id: Date.now().toString(),
        name: newMember.name,
        role: newMember.role,
        monthlyIncome: parseFloat(newMember.monthlyIncome),
      };
      
      try {
        await apiCall(`/families/${familyId}/members`, {
          method: 'POST',
          body: JSON.stringify(member),
        });
        
        setFamilyMembers([...familyMembers, member]);
        setNewMember({ name: "", role: "", monthlyIncome: "" });
        toast.success(`Added ${member.name} to family budget`);
      } catch (error) {
        console.error('Error adding family member:', error);
        toast.error('Failed to add family member');
      }
    }
  };

  const removeFamilyMember = async (id: string) => {
    try {
      await apiCall(`/families/${familyId}/members/${id}`, {
        method: 'DELETE',
      });
      
      setFamilyMembers(familyMembers.filter(member => member.id !== id));
      toast.success('Removed family member');
    } catch (error) {
      console.error('Error removing family member:', error);
      toast.error('Failed to remove family member');
    }
  };

  const addBudgetCategory = async () => {
    if (newCategory.name && newCategory.budgetAmount) {
      const category: BudgetCategory = {
        id: Date.now().toString(),
        name: newCategory.name,
        budgetAmount: parseFloat(newCategory.budgetAmount),
        actualSpent: 0,
        color: `#${Math.floor(Math.random()*16777215).toString(16)}`,
      };
      
      try {
        await apiCall(`/families/${familyId}/categories`, {
          method: 'POST',
          body: JSON.stringify(category),
        });
        
        setBudgetCategories([...budgetCategories, category]);
        setNewCategory({ name: "", budgetAmount: "" });
        toast.success(`Added ${category.name} budget category`);
      } catch (error) {
        console.error('Error adding budget category:', error);
        toast.error('Failed to add budget category');
      }
    }
  };

  const updateBudgetAmount = async (id: string, amount: number) => {
    try {
      await apiCall(`/families/${familyId}/categories/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ budgetAmount: amount }),
      });
      
      setBudgetCategories(prev => prev.map(cat => 
        cat.id === id ? { ...cat, budgetAmount: amount } : cat
      ));
    } catch (error) {
      console.error('Error updating budget amount:', error);
      toast.error('Failed to update budget amount');
    }
  };

  const updateActualSpent = async (id: string, amount: number) => {
    try {
      await apiCall(`/families/${familyId}/categories/${id}`, {
        method: 'PUT',
        body: JSON.stringify({ actualSpent: amount }),
      });
      
      setBudgetCategories(prev => prev.map(cat => 
        cat.id === id ? { ...cat, actualSpent: amount } : cat
      ));
    } catch (error) {
      console.error('Error updating actual spent:', error);
      toast.error('Failed to update spending amount');
    }
  };

  const handleApplyBudgetPlan = (budgetPlan: any[]) => {
    // Convert budget plan to budget categories
    const newCategories = budgetPlan.map(plan => ({
      id: Date.now().toString() + Math.random().toString(),
      name: plan.category,
      budgetAmount: plan.amount,
      actualSpent: 0,
      color: plan.color,
    }));
    
    setBudgetCategories(newCategories);
    setShowBudgetPlanning(false);
    toast.success("Budget plan applied! You can now track your spending.");
  };

  const totalIncome = familyMembers.reduce((sum, member) => sum + member.monthlyIncome, 0);
  const totalBudget = budgetCategories.reduce((sum, cat) => sum + cat.budgetAmount, 0);
  const totalSpent = budgetCategories.reduce((sum, cat) => sum + cat.actualSpent, 0);
  const totalSavings = totalIncome - totalSpent;

  const pieChartData = budgetCategories.filter(cat => cat.budgetAmount > 0).map(cat => ({
    name: cat.name,
    value: cat.budgetAmount,
    color: cat.color,
  }));

  const barChartData = budgetCategories.filter(cat => cat.budgetAmount > 0).map(cat => ({
    name: cat.name,
    budget: cat.budgetAmount,
    spent: cat.actualSpent,
    remaining: Math.max(0, cat.budgetAmount - cat.actualSpent),
  }));

  if (showBudgetPlanning) {
    return (
      <BudgetPlanningPage
        familyMembers={familyMembers}
        onBack={() => setShowBudgetPlanning(false)}
        onApplyBudget={handleApplyBudgetPlan}
      />
    );
  }

  if (isLoading && !isInitialized) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 flex items-center justify-center">
        <div className="text-center text-white">
          <Loader2 className="h-12 w-12 animate-spin mx-auto mb-4" />
          <p className="text-xl">Loading your family budget...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-500 to-red-500 relative overflow-hidden">
      {/* Background Images */}
      <div className="absolute inset-0 opacity-10">
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1758686254550-c5d8f4de1b3a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYW1pbHklMjBidWRnZXQlMjBtb25leSUyMHBsYW5uaW5nfGVufDF8fHx8MTc1ODg5ODAxMXww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Family budget planning"
          className="w-full h-full object-cover"
        />
      </div>
      
      <div className="relative z-10 container mx-auto p-6">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-4 mb-4">
            <h1 className="text-4xl text-white bg-black/20 rounded-lg p-4 backdrop-blur-sm">
              🏠 Family Budget Planner 💰
            </h1>
            <div className="flex gap-3">
              <Button
                onClick={() => setShowBudgetPlanning(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                disabled={familyMembers.length === 0}
              >
                <Calculator className="h-4 w-4 mr-2" />
                Smart Budget Plan
              </Button>
              <Button
                onClick={saveFamilyData}
                disabled={isLoading}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                Save Data
              </Button>
            </div>
          </div>
          <p className="text-white/90 text-lg bg-black/20 rounded-lg p-2 backdrop-blur-sm">
            Manage your family's income, expenses, and savings all in one place
          </p>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100">Total Income</p>
                  <p className="text-2xl">${totalIncome.toLocaleString()}</p>
                </div>
                <DollarSign className="h-8 w-8" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100">Total Budget</p>
                  <p className="text-2xl">${totalBudget.toLocaleString()}</p>
                </div>
                <Target className="h-8 w-8" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100">Total Spent</p>
                  <p className="text-2xl">${totalSpent.toLocaleString()}</p>
                </div>
                <TrendingUp className="h-8 w-8" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100">Total Savings</p>
                  <p className="text-2xl">${totalSavings.toLocaleString()}</p>
                </div>
                <Users className="h-8 w-8" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="members" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 bg-white/20 backdrop-blur-sm">
            <TabsTrigger value="members" className="data-[state=active]:bg-white/80">Family Members</TabsTrigger>
            <TabsTrigger value="budget" className="data-[state=active]:bg-white/80">Budget Categories</TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-white/80">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="members" className="space-y-6">
            <Card className="bg-white/95 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Family Members & Income
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add Member Form */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div>
                    <Label htmlFor="memberName">Name</Label>
                    <Input
                      id="memberName"
                      value={newMember.name}
                      onChange={(e) => setNewMember({...newMember, name: e.target.value})}
                      placeholder="Enter name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="memberRole">Role</Label>
                    <Input
                      id="memberRole"
                      value={newMember.role}
                      onChange={(e) => setNewMember({...newMember, role: e.target.value})}
                      placeholder="e.g., Father, Mother, Son"
                    />
                  </div>
                  <div>
                    <Label htmlFor="memberIncome">Monthly Income ($)</Label>
                    <Input
                      id="memberIncome"
                      type="number"
                      value={newMember.monthlyIncome}
                      onChange={(e) => setNewMember({...newMember, monthlyIncome: e.target.value})}
                      placeholder="0"
                    />
                  </div>
                  <div className="flex items-end">
                    <Button onClick={addFamilyMember} className="w-full bg-green-600 hover:bg-green-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Member
                    </Button>
                  </div>
                </div>

                {/* Members List */}
                <div className="space-y-3">
                  {familyMembers.map((member) => (
                    <div key={member.id} className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white">
                          {member.name.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <h3 className="font-medium">{member.name}</h3>
                          <Badge variant="secondary">{member.role}</Badge>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-lg font-medium text-green-600">
                            ${member.monthlyIncome.toLocaleString()}
                          </p>
                          <p className="text-sm text-gray-500">per month</p>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => removeFamilyMember(member.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="budget" className="space-y-6">
            <Card className="bg-white/95 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Budget Categories
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add Category Form */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
                  <div>
                    <Label htmlFor="categoryName">Category Name</Label>
                    <Input
                      id="categoryName"
                      value={newCategory.name}
                      onChange={(e) => setNewCategory({...newCategory, name: e.target.value})}
                      placeholder="e.g., Dining Out"
                    />
                  </div>
                  <div>
                    <Label htmlFor="categoryBudget">Budget Amount ($)</Label>
                    <Input
                      id="categoryBudget"
                      type="number"
                      value={newCategory.budgetAmount}
                      onChange={(e) => setNewCategory({...newCategory, budgetAmount: e.target.value})}
                      placeholder="0"
                    />
                  </div>
                  <div className="flex items-end">
                    <Button onClick={addBudgetCategory} className="w-full bg-purple-600 hover:bg-purple-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Category
                    </Button>
                  </div>
                </div>

                {/* Budget Categories */}
                <div className="space-y-3">
                  {budgetCategories.map((category) => (
                    <div key={category.id} className="p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-medium flex items-center gap-2">
                          <div 
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: category.color }}
                          />
                          {category.name}
                        </h3>
                        <Badge 
                          variant={category.actualSpent > category.budgetAmount ? "destructive" : "default"}
                        >
                          {category.actualSpent > category.budgetAmount ? "Over Budget" : "On Track"}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <Label>Budget Amount ($)</Label>
                          <Input
                            type="number"
                            value={category.budgetAmount}
                            onChange={(e) => updateBudgetAmount(category.id, parseFloat(e.target.value) || 0)}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label>Actual Spent ($)</Label>
                          <Input
                            type="number"
                            value={category.actualSpent}
                            onChange={(e) => updateActualSpent(category.id, parseFloat(e.target.value) || 0)}
                            className="mt-1"
                          />
                        </div>
                        <div>
                          <Label>Remaining ($)</Label>
                          <div className="mt-1 p-2 bg-white rounded border text-center font-medium">
                            ${(category.budgetAmount - category.actualSpent).toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Budget Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  {pieChartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={pieChartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {pieChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`$${value}`, 'Budget']} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-300 flex items-center justify-center text-gray-500">
                      No budget data to display
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="bg-white/95 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle>Budget vs Actual Spending</CardTitle>
                </CardHeader>
                <CardContent>
                  {barChartData.length > 0 ? (
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={barChartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip formatter={(value) => `$${value}`} />
                        <Legend />
                        <Bar dataKey="budget" fill="#8884d8" name="Budget" />
                        <Bar dataKey="spent" fill="#82ca9d" name="Spent" />
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-300 flex items-center justify-center text-gray-500">
                      No spending data to display
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Savings Summary */}
            <Card className="bg-gradient-to-r from-green-400 to-blue-500 text-white">
              <CardHeader>
                <CardTitle>💰 Savings Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <p className="text-green-100 mb-2">Monthly Income</p>
                    <p className="text-3xl">${totalIncome.toLocaleString()}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-green-100 mb-2">Total Spent</p>
                    <p className="text-3xl">${totalSpent.toLocaleString()}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-green-100 mb-2">Money Saved</p>
                    <p className="text-4xl font-bold">${totalSavings.toLocaleString()}</p>
                    <p className="text-green-200">
                      {totalIncome > 0 ? ((totalSavings / totalIncome) * 100).toFixed(1) : 0}% of income
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}