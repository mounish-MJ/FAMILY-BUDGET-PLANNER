import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { OfficerSelect } from "./OfficerSelect";
import { Shield, Users, AlertTriangle } from "lucide-react";

interface LoginPageProps {
  onLogin: (officerType: string, badgeId: string) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [officerType, setOfficerType] = useState("");
  const [badgeId, setBadgeId] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (officerType && badgeId && password) {
      onLogin(officerType, badgeId);
    }
  };

  const getOfficerIcon = () => {
    switch (officerType) {
      case "police-officer":
        return <Shield className="size-6 text-blue-600" />;
      case "traffic-officer":
        return <AlertTriangle className="size-6 text-orange-600" />;
      default:
        return <Users className="size-6 text-gray-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 p-3 bg-blue-100 rounded-full w-fit">
            {getOfficerIcon()}
          </div>
          <CardTitle>Official Login</CardTitle>
          <CardDescription>
            Access the Vehicle Tracking System
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="officer-type">Officer Type</Label>
              <OfficerSelect
                value={officerType}
                onValueChange={setOfficerType}
                placeholder="Select your role"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="badge-id">Badge ID</Label>
              <Input
                id="badge-id"
                type="text"
                placeholder="Enter your badge ID"
                value={badgeId}
                onChange={(e) => setBadgeId(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full"
              disabled={!officerType || !badgeId || !password}
            >
              Login to System
            </Button>
          </form>
          
          <div className="mt-6 p-4 bg-amber-50 rounded-lg border border-amber-200">
            <p className="text-sm text-amber-800">
              <strong>Demo Credentials:</strong><br />
              Badge ID: DEMO123<br />
              Password: demo123
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}