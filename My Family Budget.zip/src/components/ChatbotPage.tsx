import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { ScrollArea } from "./ui/scroll-area";
import { Badge } from "./ui/badge";
import { Send, Bot, User, LogOut, Search, MapPin } from "lucide-react";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
  vehicleData?: {
    number: string;
    location: string;
    lastSeen: string;
    signals: string[];
  };
}

interface ChatbotPageProps {
  officerType: string;
  badgeId: string;
  onLogout: () => void;
  onShowMap: (vehicleNumber: string) => void;
}

export function ChatbotPage({ officerType, badgeId, onLogout, onShowMap }: ChatbotPageProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hello! I'm your vehicle tracking assistant. You can ask me about vehicle locations, traffic violations, or search by vehicle number.",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [inputText, setInputText] = useState("");
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const vehicleDatabase = {
    "MH12AB1234": {
      number: "MH12AB1234",
      location: "Andheri East Signal Junction",
      lastSeen: "2 minutes ago",
      signals: ["Andheri East", "Chakala Junction", "MIDC Signal", "Airport Road"]
    },
    "DL05CD5678": {
      number: "DL05CD5678", 
      location: "CP Metro Station Signal",
      lastSeen: "5 minutes ago",
      signals: ["CP Metro", "Rajiv Chowk", "Khan Market", "Lajpat Nagar"]
    },
    "KA03EF9012": {
      number: "KA03EF9012",
      location: "Electronic City Signal",
      lastSeen: "12 minutes ago", 
      signals: ["Electronic City", "Silk Board", "BTM Layout", "Koramangala"]
    }
  };

  useEffect(() => {
    if (scrollAreaRef.current) {
      scrollAreaRef.current.scrollTop = scrollAreaRef.current.scrollHeight;
    }
  }, [messages]);

  const extractVehicleNumber = (text: string): string | null => {
    const vehicleRegex = /[A-Z]{2}\d{2}[A-Z]{2}\d{4}/g;
    const match = text.match(vehicleRegex);
    return match ? match[0] : null;
  };

  const generateBotResponse = (userMessage: string): Message => {
    const vehicleNumber = extractVehicleNumber(userMessage.toUpperCase());
    
    if (vehicleNumber && vehicleDatabase[vehicleNumber as keyof typeof vehicleDatabase]) {
      const vehicleData = vehicleDatabase[vehicleNumber as keyof typeof vehicleDatabase];
      return {
        id: Date.now().toString(),
        text: `Found vehicle ${vehicleNumber}! Current location: ${vehicleData.location}. Last seen: ${vehicleData.lastSeen}. Click "View on Map" to see the route.`,
        sender: "bot",
        timestamp: new Date(),
        vehicleData
      };
    }
    
    if (vehicleNumber) {
      return {
        id: Date.now().toString(),
        text: `Vehicle ${vehicleNumber} not found in our system. Please verify the number or check if the vehicle has passed through any monitored signals recently.`,
        sender: "bot",
        timestamp: new Date(),
      };
    }
    
    if (userMessage.toLowerCase().includes("help")) {
      return {
        id: Date.now().toString(),
        text: "I can help you with:\n• Track vehicles by number (e.g., MH12AB1234)\n• View recent vehicle locations\n• Check traffic signal crossings\n• Access violation records\n\nJust type a vehicle number or ask me anything!",
        sender: "bot",
        timestamp: new Date(),
      };
    }
    
    return {
      id: Date.now().toString(),
      text: "I understand you're looking for vehicle information. Please provide a vehicle registration number (e.g., MH12AB1234) and I'll help you track its location and signal crossings.",
      sender: "bot",
      timestamp: new Date(),
    };
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    
    setTimeout(() => {
      const botResponse = generateBotResponse(inputText);
      setMessages(prev => [...prev, botResponse]);
    }, 1000);

    setInputText("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage();
    }
  };

  const formatOfficerType = (type: string) => {
    return type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bot className="size-8 text-blue-600" />
            <div>
              <h1>Vehicle Tracking System</h1>
              <p className="text-muted-foreground text-sm">AI Assistant for Traffic Officials</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="secondary">{formatOfficerType(officerType)}</Badge>
            <Badge variant="outline">{badgeId}</Badge>
            <Button variant="outline" size="sm" onClick={onLogout}>
              <LogOut className="size-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="max-w-4xl mx-auto p-4">
        <Card className="h-[calc(100vh-200px)]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="size-5" />
              Vehicle Search & Tracking
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col h-full">
            {/* Messages */}
            <ScrollArea ref={scrollAreaRef} className="flex-1 pr-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}>
                    <div className={`flex gap-3 max-w-[80%] ${message.sender === "user" ? "flex-row-reverse" : ""}`}>
                      <div className={`size-8 rounded-full flex items-center justify-center ${
                        message.sender === "user" ? "bg-blue-600" : "bg-gray-600"
                      }`}>
                        {message.sender === "user" ? 
                          <User className="size-4 text-white" /> : 
                          <Bot className="size-4 text-white" />
                        }
                      </div>
                      <div className={`rounded-lg p-3 ${
                        message.sender === "user" 
                          ? "bg-blue-600 text-white" 
                          : "bg-gray-100 text-gray-900"
                      }`}>
                        <p className="whitespace-pre-line">{message.text}</p>
                        {message.vehicleData && (
                          <div className="mt-3 pt-3 border-t border-gray-300">
                            <div className="space-y-2 text-sm">
                              <div><strong>Vehicle:</strong> {message.vehicleData.number}</div>
                              <div><strong>Location:</strong> {message.vehicleData.location}</div>
                              <div><strong>Last Seen:</strong> {message.vehicleData.lastSeen}</div>
                              <div><strong>Recent Signals:</strong> {message.vehicleData.signals.join(" → ")}</div>
                            </div>
                            <Button 
                              size="sm" 
                              className="mt-3 bg-green-600 hover:bg-green-700"
                              onClick={() => onShowMap(message.vehicleData!.number)}
                            >
                              <MapPin className="size-4 mr-2" />
                              View on Map
                            </Button>
                          </div>
                        )}
                        <p className="text-xs opacity-70 mt-2">
                          {message.timestamp.toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Input */}
            <div className="flex gap-2 mt-4">
              <Input
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Enter vehicle number (e.g., MH12AB1234) or ask me anything..."
                className="flex-1"
              />
              <Button onClick={handleSendMessage} disabled={!inputText.trim()}>
                <Send className="size-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}