import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, LineChart, Line, Area, AreaChart } from "recharts";
import { ArrowLeft, Calculator, PiggyBank, Home, Car, Heart, GraduationCap, Gamepad2, ShoppingCart, Zap, DollarSign, Target, TrendingUp, Plane, Shield, BookOpen, Plus, Trash2 } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { toast } from "sonner@2.0.3";

interface FamilyMember {
  id: string;
  name: string;
  role: string;
  monthlyIncome: number;
}

interface BudgetPlan {
  category: string;
  percentage: number;
  amount: number;
  description: string;
  icon: any;
  color: string;
}

interface SavingsGoal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  priority: 'high' | 'medium' | 'low';
  icon: any;
  color: string;
}

interface BudgetPlanningPageProps {
  familyMembers: FamilyMember[];
  onBack: () => void;
  onApplyBudget: (budgetPlan: BudgetPlan[]) => void;
}

export default function BudgetPlanningPage({ familyMembers, onBack, onApplyBudget }: BudgetPlanningPageProps) {
  const [selectedPlan, setSelectedPlan] = useState<string>("50-30-20");
  const [customIncome, setCustomIncome] = useState<string>("");
  const [budgetPlans, setBudgetPlans] = useState<BudgetPlan[]>([]);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>([
    {
      id: "1",
      name: "Emergency Fund",
      targetAmount: 10000,
      currentAmount: 2500,
      targetDate: "2025-12-31",
      priority: "high",
      icon: Shield,
      color: "#ef4444"
    },
    {
      id: "2", 
      name: "Vacation Fund",
      targetAmount: 5000,
      currentAmount: 1200,
      targetDate: "2025-07-01",
      priority: "medium",
      icon: Plane,
      color: "#3b82f6"
    },
    {
      id: "3",
      name: "Children's Education",
      targetAmount: 25000,
      currentAmount: 8000,
      targetDate: "2030-01-01",
      priority: "high",
      icon: BookOpen,
      color: "#10b981"
    }
  ]);
  const [newGoal, setNewGoal] = useState({
    name: "",
    targetAmount: "",
    targetDate: "",
    priority: "medium" as const
  });

  const totalFamilyIncome = familyMembers.reduce((sum, member) => sum + member.monthlyIncome, 0);
  const workingIncome = customIncome ? parseFloat(customIncome) : totalFamilyIncome;

  // Predefined budget planning strategies
  const budgetStrategies = {
    "50-30-20": {
      name: "50/30/20 Rule",
      description: "Popular balanced approach: 50% needs, 30% wants, 20% savings",
      categories: [
        { category: "Housing & Utilities", percentage: 30, description: "Rent, mortgage, utilities, maintenance", icon: Home, color: "#8884d8" },
        { category: "Food & Groceries", percentage: 15, description: "Essential food and household items", icon: ShoppingCart, color: "#82ca9d" },
        { category: "Transportation", percentage: 5, description: "Car payments, gas, public transport", icon: Car, color: "#ffc658" },
        { category: "Entertainment", percentage: 15, description: "Dining out, movies, hobbies", icon: Gamepad2, color: "#ff7300" },
        { category: "Personal Care", percentage: 10, description: "Clothing, personal items", icon: Heart, color: "#00c49f" },
        { category: "Shopping", percentage: 5, description: "Non-essential purchases", icon: ShoppingCart, color: "#ffbb28" },
        { category: "Emergency Savings", percentage: 10, description: "Emergency fund (3-6 months expenses)", icon: Shield, color: "#ef4444" },
        { category: "Long-term Savings", percentage: 8, description: "Retirement, investments", icon: PiggyBank, color: "#8dd1e1" },
        { category: "Goal Savings", percentage: 2, description: "Vacation, special purchases", icon: Target, color: "#06b6d4" },
      ]
    },
    "conservative": {
      name: "Conservative Plan",
      description: "Focus on savings and essential spending - 35% total savings",
      categories: [
        { category: "Housing & Utilities", percentage: 25, description: "Rent, mortgage, utilities, maintenance", icon: Home, color: "#8884d8" },
        { category: "Food & Groceries", percentage: 15, description: "Essential food and household items", icon: ShoppingCart, color: "#82ca9d" },
        { category: "Transportation", percentage: 10, description: "Car payments, gas, public transport", icon: Car, color: "#ffc658" },
        { category: "Healthcare", percentage: 8, description: "Insurance, medical expenses", icon: Heart, color: "#00c49f" },
        { category: "Entertainment", percentage: 7, description: "Limited entertainment budget", icon: Gamepad2, color: "#ff7300" },
        { category: "Emergency Savings", percentage: 15, description: "Emergency fund (6-12 months)", icon: Shield, color: "#ef4444" },
        { category: "Retirement Savings", percentage: 12, description: "Long-term retirement fund", icon: PiggyBank, color: "#8dd1e1" },
        { category: "Investment Savings", percentage: 8, description: "Growth investments", icon: TrendingUp, color: "#10b981" },
      ]
    },
    "family-focused": {
      name: "Family Focused",
      description: "Optimized for families with children - 18% savings focus",
      categories: [
        { category: "Housing & Utilities", percentage: 28, description: "Family home, utilities", icon: Home, color: "#8884d8" },
        { category: "Food & Groceries", percentage: 18, description: "Family meals, groceries", icon: ShoppingCart, color: "#82ca9d" },
        { category: "Transportation", percentage: 12, description: "Family vehicle, transport", icon: Car, color: "#ffc658" },
        { category: "Education", percentage: 15, description: "School, tutoring, supplies", icon: GraduationCap, color: "#ff7300" },
        { category: "Healthcare", percentage: 8, description: "Family health insurance, medical", icon: Heart, color: "#00c49f" },
        { category: "Entertainment", percentage: 1, description: "Family activities, outings", icon: Gamepad2, color: "#ffbb28" },
        { category: "Emergency Savings", percentage: 8, description: "Family emergency fund", icon: Shield, color: "#ef4444" },
        { category: "Children's Future", percentage: 7, description: "Education & future savings", icon: BookOpen, color: "#10b981" },
        { category: "Retirement Savings", percentage: 3, description: "Parents' retirement", icon: PiggyBank, color: "#8dd1e1" },
      ]
    },
    "aggressive-savings": {
      name: "Aggressive Savings",
      description: "Maximize savings for early retirement - 55% total savings!",
      categories: [
        { category: "Housing & Utilities", percentage: 20, description: "Minimal housing costs", icon: Home, color: "#8884d8" },
        { category: "Food & Groceries", percentage: 12, description: "Essential food only", icon: ShoppingCart, color: "#82ca9d" },
        { category: "Transportation", percentage: 8, description: "Minimal transport costs", icon: Car, color: "#ffc658" },
        { category: "Healthcare", percentage: 5, description: "Basic healthcare", icon: Heart, color: "#00c49f" },
        { category: "Emergency Savings", percentage: 15, description: "Large emergency fund", icon: Shield, color: "#ef4444" },
        { category: "Retirement Savings", percentage: 25, description: "Maximum retirement savings", icon: PiggyBank, color: "#8dd1e1" },
        { category: "Investment Savings", percentage: 12, description: "Growth investments", icon: TrendingUp, color: "#10b981" },
        { category: "Goal Savings", percentage: 3, description: "Special goals fund", icon: Target, color: "#06b6d4" },
      ]
    },
    "wealth-building": {
      name: "Wealth Building",
      description: "Focus on building long-term wealth - 40% savings rate",
      categories: [
        { category: "Housing & Utilities", percentage: 25, description: "Reasonable housing costs", icon: Home, color: "#8884d8" },
        { category: "Food & Groceries", percentage: 12, description: "Efficient food spending", icon: ShoppingCart, color: "#82ca9d" },
        { category: "Transportation", percentage: 8, description: "Efficient transport", icon: Car, color: "#ffc658" },
        { category: "Healthcare", percentage: 6, description: "Health maintenance", icon: Heart, color: "#00c49f" },
        { category: "Entertainment", percentage: 9, description: "Moderate entertainment", icon: Gamepad2, color: "#ff7300" },
        { category: "Emergency Savings", percentage: 10, description: "Solid emergency fund", icon: Shield, color: "#ef4444" },
        { category: "Investment Portfolio", percentage: 20, description: "Diversified investments", icon: TrendingUp, color: "#10b981" },
        { category: "Retirement Savings", percentage: 10, description: "Retirement planning", icon: PiggyBank, color: "#8dd1e1" },
      ]
    }
  };

  useEffect(() => {
    if (workingIncome > 0) {
      const strategy = budgetStrategies[selectedPlan as keyof typeof budgetStrategies];
      const newBudgetPlans = strategy.categories.map(cat => ({
        ...cat,
        amount: Math.round((workingIncome * cat.percentage) / 100)
      }));
      setBudgetPlans(newBudgetPlans);
    }
  }, [selectedPlan, workingIncome]);

  const addSavingsGoal = () => {
    if (newGoal.name && newGoal.targetAmount && newGoal.targetDate) {
      const goal: SavingsGoal = {
        id: Date.now().toString(),
        name: newGoal.name,
        targetAmount: parseFloat(newGoal.targetAmount),
        currentAmount: 0,
        targetDate: newGoal.targetDate,
        priority: newGoal.priority,
        icon: Target,
        color: newGoal.priority === 'high' ? '#ef4444' : newGoal.priority === 'medium' ? '#3b82f6' : '#10b981'
      };
      setSavingsGoals([...savingsGoals, goal]);
      setNewGoal({ name: "", targetAmount: "", targetDate: "", priority: "medium" });
      toast.success(`Added savings goal: ${goal.name}`);
    }
  };

  const removeSavingsGoal = (id: string) => {
    setSavingsGoals(savingsGoals.filter(goal => goal.id !== id));
    toast.success('Removed savings goal');
  };

  const updateGoalProgress = (id: string, currentAmount: number) => {
    setSavingsGoals(prev => prev.map(goal => 
      goal.id === id ? { ...goal, currentAmount } : goal
    ));
  };

  const handleApplyBudget = () => {
    if (budgetPlans.length > 0) {
      onApplyBudget(budgetPlans);
      toast.success("Budget plan applied successfully!");
    }
  };

  const totalSavingsPercentage = budgetPlans
    .filter(plan => plan.category.toLowerCase().includes('saving') || 
                   plan.category.toLowerCase().includes('emergency') ||
                   plan.category.toLowerCase().includes('investment') ||
                   plan.category.toLowerCase().includes('retirement') ||
                   plan.category.toLowerCase().includes('goal'))
    .reduce((sum, plan) => sum + plan.percentage, 0);

  const totalSavingsAmount = budgetPlans
    .filter(plan => plan.category.toLowerCase().includes('saving') || 
                   plan.category.toLowerCase().includes('emergency') ||
                   plan.category.toLowerCase().includes('investment') ||
                   plan.category.toLowerCase().includes('retirement') ||
                   plan.category.toLowerCase().includes('goal'))
    .reduce((sum, plan) => sum + plan.amount, 0);

  const monthsToGoals = savingsGoals.map(goal => {
    const monthlyProgress = totalSavingsAmount / savingsGoals.length;
    const remaining = goal.targetAmount - goal.currentAmount;
    return {
      name: goal.name,
      monthsNeeded: monthlyProgress > 0 ? Math.ceil(remaining / monthlyProgress) : 999,
      targetDate: new Date(goal.targetDate).toLocaleDateString(),
      progress: (goal.currentAmount / goal.targetAmount) * 100
    };
  });

  const pieChartData = budgetPlans.map(plan => ({
    name: plan.category,
    value: plan.amount,
    percentage: plan.percentage,
    color: plan.color,
  }));

  const barChartData = budgetPlans.map(plan => ({
    name: plan.category.length > 12 ? plan.category.substring(0, 12) + "..." : plan.category,
    amount: plan.amount,
    percentage: plan.percentage,
  }));

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-500 via-purple-600 to-pink-500 relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-10">
        <ImageWithFallback 
          src="https://images.unsplash.com/photo-1758518727667-995863b2de71?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidWRnZXQlMjBwbGFubmluZyUyMHN0cmF0ZWd5JTIwZmluYW5jaWFsfGVufDF8fHx8MTc1ODk0NzQ1M3ww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Budget planning strategy"
          className="w-full h-full object-cover"
        />
      </div>

      <div className="relative z-10 container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Button
            onClick={onBack}
            variant="secondary"
            className="bg-white/20 backdrop-blur-sm text-white hover:bg-white/30"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Budget
          </Button>
          <div className="text-center">
            <h1 className="text-4xl text-white bg-black/20 rounded-lg p-4 backdrop-blur-sm">
              📊 Smart Budget Planner 🎯
            </h1>
            <p className="text-white/90 text-lg bg-black/20 rounded-lg p-2 mt-2 backdrop-blur-sm">
              AI-powered budget recommendations based on your family income
            </p>
          </div>
          <div className="w-32"></div> {/* Spacer for centering */}
        </div>

        {/* Income Summary */}
        <Card className="bg-white/95 backdrop-blur-sm mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5" />
              Income Summary & Custom Planning
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-gradient-to-r from-green-100 to-green-200 rounded-lg">
                <p className="text-green-700 mb-2">Family Members</p>
                <p className="text-2xl font-bold text-green-800">{familyMembers.length}</p>
                <div className="mt-2 space-y-1">
                  {familyMembers.map(member => (
                    <div key={member.id} className="text-sm text-green-600">
                      {member.name}: ${member.monthlyIncome.toLocaleString()}
                    </div>
                  ))}
                </div>
              </div>
              <div className="text-center p-4 bg-gradient-to-r from-blue-100 to-blue-200 rounded-lg">
                <p className="text-blue-700 mb-2">Total Family Income</p>
                <p className="text-3xl font-bold text-blue-800">${totalFamilyIncome.toLocaleString()}</p>
                <p className="text-sm text-blue-600 mt-1">per month</p>
              </div>
              <div className="p-4 bg-gradient-to-r from-purple-100 to-purple-200 rounded-lg">
                <Label htmlFor="customIncome" className="text-purple-700">Custom Income for Planning</Label>
                <Input
                  id="customIncome"
                  type="number"
                  value={customIncome}
                  onChange={(e) => setCustomIncome(e.target.value)}
                  placeholder={totalFamilyIncome.toString()}
                  className="mt-2"
                />
                <p className="text-sm text-purple-600 mt-1">Leave empty to use family income</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="strategies" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/20 backdrop-blur-sm">
            <TabsTrigger value="strategies" className="data-[state=active]:bg-white/80">Budget Strategies</TabsTrigger>
            <TabsTrigger value="savings" className="data-[state=active]:bg-white/80">Savings Goals</TabsTrigger>
            <TabsTrigger value="details" className="data-[state=active]:bg-white/80">Plan Details</TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-white/80">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="strategies" className="space-y-6">
            {/* Savings Highlight Banner */}
            <Card className="bg-gradient-to-r from-green-400 to-blue-500 text-white">
              <CardContent className="p-6">
                <div className="text-center">
                  <h2 className="text-2xl mb-2">💰 Smart Savings Focus</h2>
                  <p className="text-lg">Choose a strategy that maximizes your family's savings potential</p>
                  {workingIncome > 0 && (
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-green-100">Current Monthly Income</p>
                        <p className="text-2xl">${workingIncome.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-green-100">Projected Savings Rate</p>
                        <p className="text-2xl">{totalSavingsPercentage}%</p>
                      </div>
                      <div>
                        <p className="text-green-100">Monthly Savings</p>
                        <p className="text-2xl">${totalSavingsAmount.toLocaleString()}</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.entries(budgetStrategies).map(([key, strategy]) => {
                const savingsRate = strategy.categories
                  .filter(cat => cat.category.toLowerCase().includes('saving') || 
                                cat.category.toLowerCase().includes('emergency') ||
                                cat.category.toLowerCase().includes('investment') ||
                                cat.category.toLowerCase().includes('retirement') ||
                                cat.category.toLowerCase().includes('goal'))
                  .reduce((sum, cat) => sum + cat.percentage, 0);

                return (
                  <Card 
                    key={key}
                    className={`cursor-pointer transition-all ${
                      selectedPlan === key 
                        ? 'bg-gradient-to-r from-blue-50 to-indigo-100 border-2 border-blue-500' 
                        : 'bg-white/95 hover:bg-white border border-gray-200'
                    } backdrop-blur-sm`}
                    onClick={() => setSelectedPlan(key)}
                  >
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span className="text-lg">{strategy.name}</span>
                        {selectedPlan === key && (
                          <Badge className="bg-blue-500 text-white">Selected</Badge>
                        )}
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <PiggyBank className="h-5 w-5 text-green-600" />
                        <span className="text-2xl font-bold text-green-600">{savingsRate}%</span>
                        <span className="text-sm text-gray-600">savings rate</span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 mb-4 text-sm">{strategy.description}</p>
                      <div className="space-y-2">
                        {strategy.categories
                          .filter(cat => cat.category.toLowerCase().includes('saving') || 
                                        cat.category.toLowerCase().includes('emergency') ||
                                        cat.category.toLowerCase().includes('investment') ||
                                        cat.category.toLowerCase().includes('retirement') ||
                                        cat.category.toLowerCase().includes('goal'))
                          .map((cat, index) => (
                            <div key={index} className="flex items-center justify-between text-sm bg-green-50 p-2 rounded">
                              <span className="flex items-center gap-2">
                                <cat.icon className="h-4 w-4" style={{ color: cat.color }} />
                                {cat.category}
                              </span>
                              <span className="font-medium text-green-700">{cat.percentage}%</span>
                            </div>
                          ))}
                        <div className="text-xs text-gray-500 mt-2">
                          + {strategy.categories.filter(cat => !cat.category.toLowerCase().includes('saving') && 
                                                              !cat.category.toLowerCase().includes('emergency') &&
                                                              !cat.category.toLowerCase().includes('investment') &&
                                                              !cat.category.toLowerCase().includes('retirement') &&
                                                              !cat.category.toLowerCase().includes('goal')).length} expense categories
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="savings" className="space-y-6">
            <Card className="bg-white/95 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Savings Goals & Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Add New Goal Form */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
                  <div>
                    <Label htmlFor="goalName">Goal Name</Label>
                    <Input
                      id="goalName"
                      value={newGoal.name}
                      onChange={(e) => setNewGoal({...newGoal, name: e.target.value})}
                      placeholder="e.g., New Car"
                    />
                  </div>
                  <div>
                    <Label htmlFor="goalAmount">Target Amount ($)</Label>
                    <Input
                      id="goalAmount"
                      type="number"
                      value={newGoal.targetAmount}
                      onChange={(e) => setNewGoal({...newGoal, targetAmount: e.target.value})}
                      placeholder="10000"
                    />
                  </div>
                  <div>
                    <Label htmlFor="goalDate">Target Date</Label>
                    <Input
                      id="goalDate"
                      type="date"
                      value={newGoal.targetDate}
                      onChange={(e) => setNewGoal({...newGoal, targetDate: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="goalPriority">Priority</Label>
                    <select
                      id="goalPriority"
                      value={newGoal.priority}
                      onChange={(e) => setNewGoal({...newGoal, priority: e.target.value as 'high' | 'medium' | 'low'})}
                      className="w-full p-2 border rounded"
                    >
                      <option value="high">High</option>
                      <option value="medium">Medium</option>
                      <option value="low">Low</option>
                    </select>
                  </div>
                  <div className="flex items-end">
                    <Button onClick={addSavingsGoal} className="w-full bg-green-600 hover:bg-green-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Goal
                    </Button>
                  </div>
                </div>

                {/* Savings Goals List */}
                <div className="space-y-4">
                  {savingsGoals.map((goal) => {
                    const progress = (goal.currentAmount / goal.targetAmount) * 100;
                    const remaining = goal.targetAmount - goal.currentAmount;
                    const priorityColor = goal.priority === 'high' ? 'red' : goal.priority === 'medium' ? 'blue' : 'green';
                    
                    return (
                      <div key={goal.id} className="p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <goal.icon className="h-6 w-6" style={{ color: goal.color }} />
                            <div>
                              <h3 className="font-medium">{goal.name}</h3>
                              <div className="flex items-center gap-2">
                                <Badge variant={goal.priority === 'high' ? 'destructive' : 'default'}>
                                  {goal.priority} priority
                                </Badge>
                                <span className="text-sm text-gray-600">Target: {new Date(goal.targetDate).toLocaleDateString()}</span>
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <p className="text-lg font-medium" style={{ color: goal.color }}>
                                ${goal.currentAmount.toLocaleString()} / ${goal.targetAmount.toLocaleString()}
                              </p>
                              <p className="text-sm text-gray-600">${remaining.toLocaleString()} remaining</p>
                            </div>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => removeSavingsGoal(goal.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Progress</span>
                            <span>{progress.toFixed(1)}%</span>
                          </div>
                          <Progress value={progress} className="h-3" />
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
                            <div>
                              <Label>Update Current Amount ($)</Label>
                              <Input
                                type="number"
                                value={goal.currentAmount}
                                onChange={(e) => updateGoalProgress(goal.id, parseFloat(e.target.value) || 0)}
                                className="mt-1"
                              />
                            </div>
                            <div className="flex items-end">
                              <div className="text-sm text-gray-600">
                                <p>At current savings rate:</p>
                                <p className="font-medium">
                                  {totalSavingsAmount > 0 
                                    ? `${Math.ceil(remaining / (totalSavingsAmount / savingsGoals.length))} months to goal`
                                    : 'Set budget plan to see timeline'
                                  }
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Savings Summary */}
                {workingIncome > 0 && (
                  <Card className="bg-gradient-to-r from-blue-400 to-purple-500 text-white">
                    <CardHeader>
                      <CardTitle>📊 Savings Projection</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div className="text-center">
                          <p className="text-blue-100">Monthly Savings</p>
                          <p className="text-2xl">${totalSavingsAmount.toLocaleString()}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-blue-100">Annual Savings</p>
                          <p className="text-2xl">${(totalSavingsAmount * 12).toLocaleString()}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-blue-100">5-Year Total</p>
                          <p className="text-2xl">${(totalSavingsAmount * 60).toLocaleString()}</p>
                        </div>
                        <div className="text-center">
                          <p className="text-blue-100">Savings Rate</p>
                          <p className="text-2xl">{totalSavingsPercentage}%</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="details" className="space-y-6">
            <Card className="bg-white/95 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Detailed Budget Breakdown</span>
                  <Button 
                    onClick={handleApplyBudget}
                    className="bg-green-600 hover:bg-green-700 text-white"
                    disabled={workingIncome <= 0}
                  >
                    Apply This Budget Plan
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {workingIncome > 0 ? (
                  <div className="space-y-4">
                    <div className="text-center p-4 bg-gradient-to-r from-green-100 to-blue-100 rounded-lg mb-6">
                      <p className="text-lg">Planning for Monthly Income: 
                        <span className="font-bold text-2xl ml-2">${workingIncome.toLocaleString()}</span>
                      </p>
                    </div>
                    
                    {budgetPlans.map((plan, index) => (
                      <div key={index} className="p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg border">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <plan.icon className="h-6 w-6" style={{ color: plan.color }} />
                            <div>
                              <h3 className="font-medium">{plan.category}</h3>
                              <p className="text-sm text-gray-600">{plan.description}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-2xl font-bold" style={{ color: plan.color }}>
                              ${plan.amount.toLocaleString()}
                            </p>
                            <p className="text-sm text-gray-600">{plan.percentage}% of income</p>
                          </div>
                        </div>
                        <Progress 
                          value={plan.percentage} 
                          className="h-2"
                          style={{ 
                            background: `linear-gradient(to right, ${plan.color} 0%, ${plan.color} ${plan.percentage}%, #e5e7eb ${plan.percentage}%, #e5e7eb 100%)`
                          }}
                        />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <Calculator className="h-16 w-16 mx-auto mb-4 opacity-50" />
                    <p className="text-lg">Enter your family income to see budget recommendations</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            {workingIncome > 0 && budgetPlans.length > 0 ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-white/95 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Budget Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <PieChart>
                        <Pie
                          data={pieChartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percentage }) => `${name.length > 10 ? name.substring(0, 10) + "..." : name} ${percentage}%`}
                          outerRadius={80}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {pieChartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip 
                          formatter={(value, name) => [`$${value}`, name]}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                <Card className="bg-white/95 backdrop-blur-sm">
                  <CardHeader>
                    <CardTitle>Monthly Allocation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={barChartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="name" 
                          angle={-45}
                          textAnchor="end"
                          height={100}
                        />
                        <YAxis />
                        <Tooltip 
                          formatter={(value, name) => {
                            if (name === 'amount') return [`$${value}`, 'Amount'];
                            return [value, name];
                          }}
                        />
                        <Bar dataKey="amount" fill="#8884d8" name="amount" />
                      </BarChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>

                {/* Enhanced Savings Summary */}
                <Card className="bg-gradient-to-r from-green-400 to-blue-500 text-white lg:col-span-2">
                  <CardHeader>
                    <CardTitle>💰 Smart Savings Summary</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div className="text-center">
                        <p className="text-green-100 mb-2">Monthly Income</p>
                        <p className="text-3xl">${workingIncome.toLocaleString()}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-green-100 mb-2">Monthly Expenses</p>
                        <p className="text-3xl">${(workingIncome - totalSavingsAmount).toLocaleString()}</p>
                      </div>
                    </div>
                    
                    <div className="text-center mb-6 p-4 bg-white/20 rounded-lg">
                      <p className="text-green-100 mb-2">🎯 Total Monthly Savings</p>
                      <p className="text-4xl font-bold">${totalSavingsAmount.toLocaleString()}</p>
                      <p className="text-2xl">{totalSavingsPercentage}% of income</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center">
                        <p className="text-green-100 mb-1">Annual Savings</p>
                        <p className="text-xl">${(totalSavingsAmount * 12).toLocaleString()}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-green-100 mb-1">5-Year Total</p>
                        <p className="text-xl">${(totalSavingsAmount * 60).toLocaleString()}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-green-100 mb-1">10-Year Projection</p>
                        <p className="text-xl">${(totalSavingsAmount * 120).toLocaleString()}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="bg-white/95 backdrop-blur-sm">
                <CardContent className="text-center py-12">
                  <PiggyBank className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                  <p className="text-lg text-gray-500">Set up your income to see visual budget analysis</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}