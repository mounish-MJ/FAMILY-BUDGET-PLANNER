import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Alert, AlertDescription } from "./ui/alert";
import { 
  Camera, 
  TreePine, 
  Scan, 
  CheckCircle, 
  AlertTriangle, 
  LogOut, 
  RotateCcw, 
  Zap,
  Leaf,
  Bug,
  Droplet,
  ThermometerSun
} from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface TreeMonitoringPageProps {
  userType: string;
  userId: string;
  onLogout: () => void;
}

interface TreeAnalysis {
  id: string;
  status: "healthy" | "diseased";
  confidence: number;
  diseases?: string[];
  healthMetrics: {
    leafDensity: number;
    barkCondition: number;
    overallHealth: number;
  };
  recommendations: string[];
  timestamp: Date;
}

export function TreeMonitoringPage({ userType, userId, onLogout }: TreeMonitoringPageProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [currentTree, setCurrentTree] = useState<"tree1" | "tree2" | null>(null);
  const [scanProgress, setScanProgress] = useState(0);
  const [analysis, setAnalysis] = useState<TreeAnalysis | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const treeData = {
    tree1: {
      image: "https://images.unsplash.com/photo-1604946544401-258a809815a4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGh5JTIwZ3JlZW4lMjB0cmVlJTIwZm9yZXN0fGVufDF8fHx8MTc1ODAxMjcyMHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      analysis: {
        id: "tree1",
        status: "healthy" as const,
        confidence: 94,
        healthMetrics: {
          leafDensity: 88,
          barkCondition: 92,
          overallHealth: 91
        },
        recommendations: [
          "Continue regular watering schedule",
          "Monitor for seasonal pests",
          "Maintain soil pH levels"
        ],
        timestamp: new Date()
      }
    },
    tree2: {
      image: "https://images.unsplash.com/photo-1722924609117-98ac8056219f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXNlYXNlZCUyMHRyZWUlMjBiYXJrJTIwZnVuZ3VzfGVufDF8fHx8MTc1ODAxMjcyM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      analysis: {
        id: "tree2",
        status: "diseased" as const,
        confidence: 87,
        diseases: ["Fungal bark infection", "Leaf blight", "Root rot (early stage)"],
        healthMetrics: {
          leafDensity: 34,
          barkCondition: 22,
          overallHealth: 28
        },
        recommendations: [
          "Apply antifungal treatment immediately",
          "Improve drainage around root system",
          "Remove affected branches",
          "Schedule follow-up inspection in 2 weeks"
        ],
        timestamp: new Date()
      }
    }
  };

  const startScanning = (treeId: "tree1" | "tree2") => {
    setCurrentTree(treeId);
    setIsScanning(true);
    setScanProgress(0);
    setAnalysis(null);
    
    // Simulate scanning progress
    const interval = setInterval(() => {
      setScanProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsScanning(false);
          setAnalysis(treeData[treeId].analysis);
          return 100;
        }
        return prev + 2;
      });
    }, 100);
  };

  const resetScan = () => {
    setCurrentTree(null);
    setIsScanning(false);
    setScanProgress(0);
    setAnalysis(null);
  };

  const formatUserType = (type: string) => {
    return type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-50">
      {/* Header */}
      <div className="bg-white border-b border-green-200 p-4 shadow-sm">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <TreePine className="size-8 text-green-600" />
            <div>
              <h1>Tree Health Monitoring System</h1>
              <p className="text-muted-foreground text-sm">AI-powered tree disease detection</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              {formatUserType(userType)}
            </Badge>
            <Badge variant="outline">{userId}</Badge>
            <Button variant="outline" size="sm" onClick={onLogout}>
              <LogOut className="size-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Camera Feed */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="size-5" />
                Live Camera Feed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative bg-gray-900 rounded-lg overflow-hidden min-h-[400px]">
                {currentTree ? (
                  <div className="relative">
                    <ImageWithFallback
                      src={treeData[currentTree].image}
                      alt={`Tree ${currentTree === 'tree1' ? '1 (Healthy)' : '2 (Diseased)'}`}
                      className="w-full h-[400px] object-cover"
                    />
                    
                    {/* Scanning Overlay */}
                    {isScanning && (
                      <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                        <div className="text-center text-white">
                          <Scan className="size-12 mx-auto mb-4 animate-pulse" />
                          <p className="text-lg mb-4">Analyzing Tree Health...</p>
                          <Progress value={scanProgress} className="w-64 mx-auto" />
                          <p className="text-sm mt-2">{scanProgress}% Complete</p>
                        </div>
                      </div>
                    )}

                    {/* Analysis Results Overlay */}
                    {analysis && !isScanning && (
                      <div className="absolute top-4 left-4 right-4">
                        <Alert className={`${analysis.status === 'healthy' ? 'border-green-500 bg-green-50' : 'border-red-500 bg-red-50'}`}>
                          <div className="flex items-center gap-2">
                            {analysis.status === 'healthy' ? 
                              <CheckCircle className="size-5 text-green-600" /> : 
                              <AlertTriangle className="size-5 text-red-600" />
                            }
                            <AlertDescription className={analysis.status === 'healthy' ? 'text-green-800' : 'text-red-800'}>
                              <strong>
                                {analysis.status === 'healthy' ? 'Healthy Tree Detected' : 'Disease Detected'}
                              </strong> (Confidence: {analysis.confidence}%)
                            </AlertDescription>
                          </div>
                        </Alert>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-[400px] text-gray-400">
                    <div className="text-center">
                      <Camera className="size-16 mx-auto mb-4 opacity-50" />
                      <p>Select a tree to begin monitoring</p>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Control Buttons */}
              <div className="flex gap-3 mt-4">
                <Button 
                  onClick={() => startScanning('tree1')} 
                  disabled={isScanning}
                  className="flex-1 bg-green-600 hover:bg-green-700"
                >
                  <TreePine className="size-4 mr-2" />
                  Scan Tree 1 (Healthy)
                </Button>
                <Button 
                  onClick={() => startScanning('tree2')} 
                  disabled={isScanning}
                  variant="destructive"
                  className="flex-1"
                >
                  <Bug className="size-4 mr-2" />
                  Scan Tree 2 (Diseased)
                </Button>
                <Button 
                  onClick={resetScan} 
                  variant="outline"
                  disabled={isScanning}
                >
                  <RotateCcw className="size-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Analysis Panel */}
        <div className="space-y-6">
          {/* Health Metrics */}
          {analysis && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="size-5" />
                  Health Metrics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <Leaf className="size-4 text-green-600" />
                      <span className="text-sm">Leaf Density</span>
                    </div>
                    <span className="text-sm">{analysis.healthMetrics.leafDensity}%</span>
                  </div>
                  <Progress value={analysis.healthMetrics.leafDensity} />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <TreePine className="size-4 text-amber-600" />
                      <span className="text-sm">Bark Condition</span>
                    </div>
                    <span className="text-sm">{analysis.healthMetrics.barkCondition}%</span>
                  </div>
                  <Progress value={analysis.healthMetrics.barkCondition} />
                </div>
                
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <ThermometerSun className="size-4 text-blue-600" />
                      <span className="text-sm">Overall Health</span>
                    </div>
                    <span className="text-sm">{analysis.healthMetrics.overallHealth}%</span>
                  </div>
                  <Progress value={analysis.healthMetrics.overallHealth} />
                </div>
              </CardContent>
            </Card>
          )}

          {/* Disease Detection */}
          {analysis && analysis.diseases && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <Bug className="size-5" />
                  Detected Diseases
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {analysis.diseases.map((disease, index) => (
                    <div key={index} className="p-3 bg-red-50 rounded-lg border border-red-200">
                      <div className="text-sm text-red-800">{disease}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Recommendations */}
          {analysis && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Droplet className="size-5" />
                  Care Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {analysis.recommendations.map((recommendation, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg">
                      <div className="size-2 rounded-full bg-blue-500 mt-2 flex-shrink-0"></div>
                      <p className="text-sm text-blue-800">{recommendation}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* System Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="size-5" />
                System Status
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm">Camera Status</span>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  Active
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">AI Model</span>
                <Badge variant="secondary">TreeHealth v2.1</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">Last Scan</span>
                <span className="text-sm text-muted-foreground">
                  {analysis ? analysis.timestamp.toLocaleTimeString() : "No scans yet"}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}