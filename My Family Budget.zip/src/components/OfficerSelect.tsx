import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";

interface OfficerSelectProps {
  value?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
}

export function OfficerSelect({ value, onValueChange, placeholder = "Select officer type" }: OfficerSelectProps) {
  return (
    <Select value={value} onValueChange={onValueChange}>
      <SelectTrigger className="w-[200px]">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="officer">Officer</SelectItem>
        <SelectItem value="police-officer">Police Officer</SelectItem>
        <SelectItem value="traffic-officer">Traffic Officer</SelectItem>
      </SelectContent>
    </Select>
  );
}