import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { TreePine, Leaf, Shield } from "lucide-react";

interface TreeLoginPageProps {
  onLogin: (userType: string, userId: string) => void;
}

export function TreeLoginPage({ onLogin }: TreeLoginPageProps) {
  const [userType, setUserType] = useState("");
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userType && userId && password) {
      onLogin(userType, userId);
    }
  };

  const getUserIcon = () => {
    switch (userType) {
      case "forest-officer":
        return <TreePine className="size-6 text-green-600" />;
      case "botanist":
        return <Leaf className="size-6 text-emerald-600" />;
      case "researcher":
        return <Shield className="size-6 text-blue-600" />;
      default:
        return <TreePine className="size-6 text-gray-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 p-3 bg-green-100 rounded-full w-fit">
            {getUserIcon()}
          </div>
          <CardTitle>Tree Health Monitor</CardTitle>
          <CardDescription>
            Access the Tree Monitoring System
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="user-type">User Type</Label>
              <Select value={userType} onValueChange={setUserType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="forest-officer">Forest Officer</SelectItem>
                  <SelectItem value="botanist">Botanist</SelectItem>
                  <SelectItem value="researcher">Environmental Researcher</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="user-id">User ID</Label>
              <Input
                id="user-id"
                type="text"
                placeholder="Enter your user ID"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-green-600 hover:bg-green-700"
              disabled={!userType || !userId || !password}
            >
              Access Tree Monitoring
            </Button>
          </form>
          
          <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
            <p className="text-sm text-green-800">
              <strong>Demo Credentials:</strong><br />
              User ID: TREE123<br />
              Password: monitor123
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}