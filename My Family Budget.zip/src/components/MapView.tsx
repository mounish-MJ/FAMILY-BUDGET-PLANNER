import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ArrowLeft, MapPin, Clock, Route, AlertCircle, Navigation } from "lucide-react";

interface MapViewProps {
  vehicleNumber: string;
  onBack: () => void;
}

export function MapView({ vehicleNumber, onBack }: MapViewProps) {
  const [selectedSignal, setSelectedSignal] = useState<string | null>(null);

  // Mock vehicle data with route information
  const vehicleData = {
    "MH12AB1234": {
      number: "MH12AB1234",
      currentLocation: { lat: 19.1136, lng: 72.8697, name: "Andheri East Signal Junction" },
      route: [
        { id: 1, name: "MIDC Signal", time: "14:23", status: "passed", lat: 19.1076, lng: 72.8606 },
        { id: 2, name: "Chakala Junction", time: "14:28", status: "passed", lat: 19.1106, lng: 72.8656 },
        { id: 3, name: "Andheri East Signal", time: "14:32", status: "current", lat: 19.1136, lng: 72.8697 },
        { id: 4, name: "Airport Road Signal", time: "14:35", status: "upcoming", lat: 19.1166, lng: 72.8747 }
      ],
      violations: [
        { signal: "Chakala Junction", violation: "Speed Limit Exceeded", time: "14:28" }
      ]
    }
  };

  const currentVehicle = vehicleData[vehicleNumber as keyof typeof vehicleData] || vehicleData["MH12AB1234"];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "passed": return "bg-gray-500";
      case "current": return "bg-green-500 animate-pulse";
      case "upcoming": return "bg-blue-500";
      default: return "bg-gray-500";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "passed": return "Passed";
      case "current": return "Current Location";
      case "upcoming": return "Predicted Route";
      default: return "Unknown";
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm" onClick={onBack}>
              <ArrowLeft className="size-4 mr-2" />
              Back to Chat
            </Button>
            <MapPin className="size-6 text-green-600" />
            <div>
              <h1>Vehicle Location Tracking</h1>
              <p className="text-muted-foreground text-sm">Real-time signal crossing data</p>
            </div>
          </div>
          <Badge variant="outline" className="text-lg px-4 py-2">
            {vehicleNumber}
          </Badge>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map Area */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Navigation className="size-5" />
                Route Map
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Simulated Map */}
              <div className="bg-gradient-to-br from-green-50 to-blue-50 rounded-lg p-8 min-h-[500px] relative border-2 border-dashed border-gray-300">
                <div className="absolute inset-4 bg-white rounded opacity-20"></div>
                
                {/* Route Line */}
                <svg viewBox="0 0 400 300" className="absolute inset-4 w-full h-full">
                  <defs>
                    <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#6b7280" />
                      <stop offset="60%" stopColor="#10b981" />
                      <stop offset="100%" stopColor="#3b82f6" />
                    </linearGradient>
                  </defs>
                  <path
                    d="M 50 250 Q 150 150 250 200 Q 350 160 380 100"
                    stroke="url(#routeGradient)"
                    strokeWidth="4"
                    fill="none"
                    strokeDasharray="10,5"
                  />
                </svg>

                {/* Signal Points */}
                {currentVehicle.route.map((signal, index) => (
                  <div
                    key={signal.id}
                    className={`absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer`}
                    style={{
                      left: `${20 + (index * 25)}%`,
                      top: `${70 - (index * 15)}%`
                    }}
                    onClick={() => setSelectedSignal(selectedSignal === signal.name ? null : signal.name)}
                  >
                    <div className={`size-4 rounded-full ${getStatusColor(signal.status)} border-2 border-white shadow-lg`}></div>
                    <div className="mt-2 bg-white px-2 py-1 rounded shadow text-xs whitespace-nowrap">
                      <div className="font-medium">{signal.name}</div>
                      <div className="text-gray-500">{signal.time}</div>
                    </div>
                  </div>
                ))}

                {/* Map Legend */}
                <div className="absolute bottom-4 left-4 bg-white p-3 rounded-lg shadow">
                  <h4 className="text-sm font-medium mb-2">Legend</h4>
                  <div className="space-y-1 text-xs">
                    <div className="flex items-center gap-2">
                      <div className="size-3 rounded-full bg-gray-500"></div>
                      <span>Passed</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="size-3 rounded-full bg-green-500"></div>
                      <span>Current</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="size-3 rounded-full bg-blue-500"></div>
                      <span>Predicted</span>
                    </div>
                  </div>
                </div>

                <div className="absolute top-4 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-4 py-2 rounded-lg shadow">
                  <div className="text-center">
                    <div className="text-sm opacity-90">Live Tracking</div>
                    <div className="font-medium">{currentVehicle.currentLocation.name}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Vehicle Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="size-5" />
                Vehicle Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="text-sm text-muted-foreground">Registration Number</div>
                <div className="font-medium">{currentVehicle.number}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Current Location</div>
                <div className="font-medium">{currentVehicle.currentLocation.name}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Last Updated</div>
                <div className="font-medium">2 minutes ago</div>
              </div>
            </CardContent>
          </Card>

          {/* Route Timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Route className="size-5" />
                Signal Timeline
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {currentVehicle.route.map((signal, index) => (
                  <div key={signal.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50">
                    <div className={`size-3 rounded-full ${getStatusColor(signal.status)} flex-shrink-0`}></div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm">{signal.name}</div>
                      <div className="text-xs text-muted-foreground">{getStatusText(signal.status)}</div>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="size-3" />
                      {signal.time}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Violations */}
          {currentVehicle.violations.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <AlertCircle className="size-5" />
                  Traffic Violations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {currentVehicle.violations.map((violation, index) => (
                    <div key={index} className="p-3 bg-red-50 rounded-lg border border-red-200">
                      <div className="text-sm font-medium text-red-800">{violation.violation}</div>
                      <div className="text-xs text-red-600 mt-1">
                        {violation.signal} • {violation.time}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}